// @flow

import {Colors} from '../../Themes/'

export default {
  drawer: {
    backgroundColor: '#fff'
  },
  main: {
    backgroundColor: Colors.clear
  }
}
