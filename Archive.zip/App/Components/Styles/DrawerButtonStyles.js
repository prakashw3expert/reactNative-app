// @flow

import { Metrics, Colors, Fonts } from '../../Themes'

export default {
  text: {
    color: Colors.navButton,
    marginLeft: 20,
    marginVertical: Metrics.baseMargin,
  }
}
