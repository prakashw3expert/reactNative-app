// @flow

import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  callout: {
    position: 'relative',
    flex: 1
  }
})
