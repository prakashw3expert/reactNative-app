### Config Folder
All application specific configuration falls in this folder.

`DebugSettings.js` is used for development-wide globals.
`ReactotronConfig.js` is used for Reactotron client settings.
